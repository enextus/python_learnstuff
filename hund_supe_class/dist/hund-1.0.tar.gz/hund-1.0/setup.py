from setuptools import setup
setup(
 name='hund',
 version='1.0',
 description='Aufgabe 3',
 py_modules=['hund'],
)